package org.jetbrains.annotations;

public @interface NotNull {
}
